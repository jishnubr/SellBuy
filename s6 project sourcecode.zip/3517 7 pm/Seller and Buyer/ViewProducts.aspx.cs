﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
public partial class ViewProducts : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da,db;
    DataSet ds,dt;
    decimal totRatng = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
           
        }
        if (!Page.IsPostBack)
        {
            Getproductdetails();
            DropDowncategory.DataBind();
            DropDowncategory.Items.Insert(0, "--select--");
        } 
    }
    private void Getprovider()
    {
        int uid;
    foreach (GridViewRow gr in GridView1.Rows)
            {
                Label Productid = (Label)gr.Cells[1].FindControl("Productid");
                if (Productid.Text != "")
                {
                    string sql1 = " select uid from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com1 = new SqlCommand(sql1, con);
                    uid = (int)com1.ExecuteScalar();
                    da = new SqlDataAdapter(" select username from Users where uid=" + uid + " and status = 'Active'", con);
                    ds = new DataSet();
                    da.Fill(ds, "Usrs");
                    if (ds.Tables.Count > 0 && ds.Tables["Usrs"].Rows.Count > 0)
                    {
                        gr.Cells[2].Text = ds.Tables["Usrs"].Rows[0][0].ToString();
                    }
                    else
                    {
                        gr.Cells[2].Text = "Unauthrised Provider";
                    }
                    /*Rating */
                    db = new SqlDataAdapter(" select Rating from feedbackProd where Productid=" + Convert.ToInt32(Productid.Text) + "", con);
                    dt = new DataSet();
                    db.Fill(dt, "Rating");
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count == 1)
                    {
                        gr.Cells[9].Text = dt.Tables["Rating"].Rows[0][0].ToString();
                    }
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count > 1)
                    {
                        float Ratng=0;
                        ArrayList arr = new ArrayList();
                        for (int i = 0; i < dt.Tables["Rating"].Rows.Count; i++)
                        {
                            arr.Add(dt.Tables["Rating"].Rows[i][0].ToString());
                        }
                        if (arr.Count > 0)
                        {
                            for (int j = 0; j < arr.Count; j++)
                            {
                                totRatng = totRatng + Convert.ToDecimal(arr[j]);
                            }
                            int Count = arr.Count;

                            Ratng = (float)(totRatng /Count);
                        }
                        string r = Ratng.ToString().Remove(3);
                        gr.Cells[9].Text = r;
                    }
                }
            }
        }
    private void Getproductdetails()
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,Remainitems,Type,Date from Product_Details where uid != '" + Convert.ToInt32(Session["uid"].ToString()) + "' and Remainitems  != 0 ", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");
        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["Product_Details"].DefaultView;
            Label1.Visible = false;
            GridView1.DataBind();
            int uid;
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label Productid = (Label)gr.Cells[1].FindControl("Productid");
                if (Productid.Text != "")
                {
                    string sql1 = " select uid from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com1 = new SqlCommand(sql1, con);
                    uid = (int)com1.ExecuteScalar();
                    da = new SqlDataAdapter(" select username from Users where uid=" + uid + " and status = 'Active'", con);
                    ds = new DataSet();
                    da.Fill(ds, "Usrs");
                    if (ds.Tables.Count > 0 && ds.Tables["Usrs"].Rows.Count > 0)
                    {
                        gr.Cells[2].Text = ds.Tables["Usrs"].Rows[0][0].ToString();
                    }
                    else
                    {
                        gr.Cells[2].Text = "Unauthrised Provider";
                    }
                    /*Rating */
                    db = new SqlDataAdapter(" select Rating from feedbackProd where Productid=" + Convert.ToInt32(Productid.Text) + "", con);
                    dt = new DataSet();
                    db.Fill(dt, "Rating");
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count == 1)
                    {
                        gr.Cells[9].Text = dt.Tables["Rating"].Rows[0][0].ToString();
                    }
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count > 1)
                    {
                        float Ratng = 0;
                        ArrayList arr = new ArrayList();
                        for (int i = 0; i < dt.Tables["Rating"].Rows.Count; i++)
                        {
                            arr.Add(dt.Tables["Rating"].Rows[i][0].ToString());
                        }
                        if (arr.Count > 0)
                        {
                            for (int j = 0; j < arr.Count; j++)
                            {
                                totRatng = totRatng + Convert.ToDecimal(arr[j]);
                            }
                            int Count = arr.Count;

                            Ratng = (float)(totRatng / Count);
                        }
                        string r = Ratng.ToString().Remove(3);
                        gr.Cells[9].Text = r;
                    }
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "No Products are available";
            Label2.Visible = false;
            Label3.Visible = false;
            DropDowncategory.Visible = false;
            DropDownsubcategory.Visible = false;
            Button1.Visible = false;
            Button2.Visible = false;
        }
    }
    protected void GridView1_Delete(object sender, GridViewDeleteEventArgs e)
    {
        int uid;
        Label Productid = new Label();
        Label username = new Label();
        Productid = (Label)GridView1.Rows[e.RowIndex].Cells[1].FindControl("Productid");
        string sql1 = " select uid from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
        SqlCommand com1 = new SqlCommand(sql1, con);
        uid = (int)com1.ExecuteScalar();
        string sql2 = " select count(*) from Users where uid=" + uid + " and status='Active'";
        SqlCommand com2 = new SqlCommand(sql2, con);
        int temp = Convert.ToInt32(com2.ExecuteScalar().ToString().Replace(" ", ""));
        if (temp == 1)
        {
            string duplicateID = " select count(*)   from cart where Productid=" + Convert.ToInt32(Productid.Text) + " and uid='" + Convert.ToInt32(Session["uid"].ToString()) + "'";
            SqlCommand com3 = new SqlCommand(duplicateID, con);
            temp = Convert.ToInt32(com3.ExecuteScalar().ToString());
            if (temp == 1)
            {
                Getproductdetails();
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Product Already exist in cart.Please Try Another item";
                
            }
            else
            {
                if (Productid.Text != "")
                {
                    string brID = " select ProductImage from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    string brID2 = " select cost from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com4 = new SqlCommand(brID, con);
                    SqlCommand com5 = new SqlCommand(brID2, con);

                    string path = (string)com4.ExecuteScalar();
                    int price = (int)com5.ExecuteScalar();
                    int qty = 1;
                    int totcost = (int)price;

                    da = new SqlDataAdapter("insert into Cart(uid,Productid,ProductImage,cost,qty,totcost,date)values('" + Convert.ToInt32(Session["uid"].ToString()) + "','" + Convert.ToInt32(Productid.Text) + "','" + path + "','" + price + "','" + qty + "','" + totcost + "',getdate())", con);
                    int n = da.SelectCommand.ExecuteNonQuery();
                    if (n == 1)
                    {
                        string quty = " select Remainitems from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                        SqlCommand com6 = new SqlCommand(quty, con);
                        int quaty = (int)com6.ExecuteScalar();
                        quaty = quaty - 1;

                        da = new SqlDataAdapter("update Product_Details  set Remainitems =" + quaty + " where Productid='" + Convert.ToInt32(Productid.Text) + "' ", con);
                        da.SelectCommand.ExecuteNonQuery();
                        Getprovider();
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Green;
                        Label1.Text = "This Product is added to Cart";
                    }
                    
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "This Product is invalid";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getprovider();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    { 
        Label2.Visible = true;
        DropDownsubcategory.Visible = true;
        DropDownsubcategory.DataBind();
        DropDownsubcategory.Items.Insert(0, "--select--");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    public void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        da = new SqlDataAdapter("select Productid from Product_Details where uid != '" + Convert.ToInt32(Session["uid"].ToString()) + "' and Remainitems  != 0 ", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");
        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {
            if (e.CommandName == "ViewFeedBacks")
            {
                int Productid = Convert.ToInt32(e.CommandArgument.ToString());
                Session.Add("Productid", Productid);
                Response.Redirect("ViewFeedbackProduct.aspx");
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (DropDowncategory.Text == "--select--")
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Plese Select a Category for searching";
            GridView1.DataBind();
        }
        else if (DropDownsubcategory.Text == "--select--")
        {
            ArrayList arr = new ArrayList();
            da = new SqlDataAdapter("select BrandID from Subcategory where Category='" + DropDowncategory.Text + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tbl_Brands");
            if (ds.Tables.Count > 0 && ds.Tables["tbl_Brands"].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables["tbl_Brands"].Rows.Count; i++)
                {
                    arr.Add(ds.Tables["tbl_Brands"].Rows[i][0].ToString());
                }
                if (arr.Count > 0)
                {
                    for (int j = 0; j < arr.Count; j++)
                    {
                        db = new SqlDataAdapter("select Productid,ProductName,BrandID,description,ProductImage,cost,Remainitems,Type,Date from Product_Details where BrandID='" + arr[j] + "' and uid != '" + Convert.ToInt32(Session["uid"].ToString()) + "' and Remainitems  != 0  ", con);
                        ds = new DataSet();
                        db.Fill(ds, "tbl_Product_Details");
                        if (ds.Tables.Count > 0 && ds.Tables["tbl_Product_Details"].Rows.Count > 0)
                        {
                            GridView1.DataSource = ds.Tables["tbl_Product_Details"].DefaultView;
                            GridView1.DataBind();
                            Label1.Visible = false;
                            Getprovider();
                        }
                        else
                        {
                            Label1.Visible = true;
                            Label1.ForeColor = System.Drawing.Color.Red;
                            Label1.Text = "Sorry no product is Avalable in this Category";
                            GridView1.DataBind();
                        }
                    }
                }
            }
        }
        else
        {
            string brID = " select BrandID from Subcategory where BrandName='" + DropDownsubcategory.Text + "'";
            SqlCommand com1 = new SqlCommand(brID, con);
            int BrandID = (int)com1.ExecuteScalar();

            da = new SqlDataAdapter("select Productid,ProductName,BrandID,description,ProductImage,cost,Remainitems,Type,Date from Product_Details where BrandID='" + BrandID + "' and uid != '" + Convert.ToInt32(Session["uid"].ToString()) + "'and Remainitems  != 0 ", con);
            ds = new DataSet();
            da.Fill(ds, "Product_Details");
            if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables["Product_Details"].DefaultView;
                Label1.Visible = false;
                GridView1.DataBind();
            }
            else
            {
                Label1.Visible = true;
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Sorry no product is Avalable";
                GridView1.DataBind();
            }
        }
    }
    protected void GridView1_SelectedIndexChanged1(GridViewCommandEventArgs e,object source)
    {
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label1.Visible = false;
        Getproductdetails();
    }
}