﻿using System;

public partial class UserPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)
        {
            Label_welcome.Text += Session["New"].ToString();
        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
    }
    protected void B_Logout_Click(object sender, EventArgs e)
    {
        Session["New"] = null;
        Response.Redirect("UserLogin.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
}