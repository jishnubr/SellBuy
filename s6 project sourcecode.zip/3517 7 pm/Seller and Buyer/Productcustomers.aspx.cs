﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Seller_and_Buyer_Productcustomers : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            GetproductCustomers();
        }
    }
    private void GetproductCustomers()
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems,Type,Date from Product_Details where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");

        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["Product_Details"].DefaultView;
            Label1.Visible = false;
            GridView1.DataBind();
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label totalqty2 = (Label)gr.Cells[3].FindControl("totalqty");
                Label Remainitems2 = (Label)gr.Cells[3].FindControl("Remainitems");
                if (Remainitems2.Text != totalqty2.Text)
                {
                    gr.Cells[9].Text = "Not Possible<br/>Sales Starts";
                }
            }
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "Your Sold Products List is Empty";
            Label2.Visible = false;
            LinkButton9.Visible = false;
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems ,Type,Date from Product_Details where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            Label Productid = new Label();
            Productid = (Label)GridView1.Rows[e.RowIndex].Cells[0].FindControl("Productid");
            string Product = Productid.Text;
            Session.Add("Productid", Product);
            Response.Redirect("CustomerView.aspx");
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "Your Sold Products List is Empty";
            Label2.Visible = false;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems ,Type,Date from Product_Details where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            if (e.CommandName == "ViewFeedBacks")
            {
                int Productid = Convert.ToInt32(e.CommandArgument.ToString());
                Session.Add("Productid", Productid);
                Response.Redirect("ViewFeedbackProduct.aspx");
            }
            if (e.CommandName == "UpdateProduct" && e.CommandArgument.ToString() != "")
            {
                int Productid = Convert.ToInt32(e.CommandArgument.ToString());
                string sql1 = " select Remainitems from Product_Details where Productid=" + Productid + "";
                SqlCommand com5 = new SqlCommand(sql1, con);
                int Remainitems = (int)com5.ExecuteScalar();

                string sql2 = " select totalqty from Product_Details where Productid=" + Productid + "";
                SqlCommand com6 = new SqlCommand(sql2, con);
                int totalqty = (int)com6.ExecuteScalar();
                if (Remainitems == totalqty)
                {
                    Session.Add("Productid", Productid);
                    Response.Redirect("UpdateProduct.aspx");
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Some Changes is Found Refresh This Page";
                    Response.Redirect("Productcustomers.aspx");
                }
            }

        }
    }
    
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GetproductCustomers();
    }
}