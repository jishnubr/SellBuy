﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Seller_and_Buyer_ChangeStatus : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex != -1)
        {
            /*Response.Write("Text = " + RadioButtonList1.SelectedItem.Text + "<br/>");
            Response.Write("Value = " + RadioButtonList1.SelectedItem.Value + "<br/>");
            Response.Write("Index = " + RadioButtonList1.SelectedIndex.ToString());
            */

            da = new SqlDataAdapter("update soldProducts set Status= '" + RadioButtonList1.SelectedItem.Value + "' where soldid= '" + Convert.ToInt32(Session["soldid"].ToString()) + "'", con);
            ds = new DataSet();
            int n = da.SelectCommand.ExecuteNonQuery();

            if (n == 1)
            {
                Response.Redirect("CustomerView.aspx");
            }
        }
        else
        {
            Response.Redirect("CustomerView.aspx");
        }
    }
}