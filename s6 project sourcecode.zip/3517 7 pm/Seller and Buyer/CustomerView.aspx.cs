﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
public partial class Seller_and_Buyer_CustomerView : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            GetproductCustomers();
        }
    }
    private void GetproductCustomers()
    {
        ArrayList arr = new ArrayList();
        da = new SqlDataAdapter("select soldid,uid,soldqty,Status  from soldProducts where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "tbl_uid");
        if (ds.Tables.Count > 0 && ds.Tables["tbl_uid"].Rows.Count > 0)
        {
                GridView1.DataSource = ds.Tables["tbl_uid"].DefaultView;

                GridView1.DataBind();
                Label1.Visible = false;

                string fname = "";
                string lname = "";
                string address = "";
                string city = "";
                string zip = "";
                string state = "";
                string email = "";
                string phone = "";
                string ProductName = "";

                string sql9 = " select ProductName from Product_Details where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'";
                SqlCommand com9 = new SqlCommand(sql9, con);
                ProductName = (string)com9.ExecuteScalar();

                foreach (GridViewRow gr in GridView1.Rows) 
                {
                    Label uid = (Label)gr.Cells[1].FindControl("uid");

                    if (uid.Text != "")
                    {
                        string sql1 = " select fname from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com1 = new SqlCommand(sql1, con);
                        fname = (string)com1.ExecuteScalar();
                        if (fname != "")
                        {
                            gr.Cells[3].Text = fname;
                        }
                        string sql2 = " select lname from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com2 = new SqlCommand(sql2, con);
                        lname = (string)com2.ExecuteScalar();
                        if (lname != "")
                        {
                            gr.Cells[4].Text = lname;
                        }
                        string sql3 = " select address from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com3 = new SqlCommand(sql3, con);
                        address = (string)com3.ExecuteScalar();
                        if (address != "")
                        {
                            gr.Cells[5].Text = address;
                        }
                        string sql4 = " select city from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com4 = new SqlCommand(sql4, con);
                        city = (string)com4.ExecuteScalar();
                        if (city != "")
                        {
                            gr.Cells[6].Text = city;
                        }
                        string sql5 = " select zip from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com5 = new SqlCommand(sql5, con);
                        zip = (string)com5.ExecuteScalar();
                        if (zip != "")
                        {
                            gr.Cells[7].Text = zip;
                        }
                        string sql6 = " select state from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com6 = new SqlCommand(sql6, con);
                        state = (string)com6.ExecuteScalar();
                        if (state != "")
                        {
                            gr.Cells[8].Text = state;
                        }
                        string sql7 = " select email from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com7 = new SqlCommand(sql7, con);
                        email = (string)com7.ExecuteScalar();
                        if (email != "")
                        {
                            gr.Cells[9].Text = email;
                        }
                        string sql8 = " select phone from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                        SqlCommand com8 = new SqlCommand(sql8, con);
                        phone = (string)com8.ExecuteScalar();
                        if (phone != "")
                        {
                            gr.Cells[10].Text = phone;
                        }
                    }
                }
                Label1.ForeColor = System.Drawing.Color.Green;
                Label1.Visible = true;
                Label1.Text = "Customer Details For Product '" + ProductName + "'";
            }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Customer list is Empty";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GetproductCustomers();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        da = new SqlDataAdapter("select soldid,uid,soldqty,Status  from soldProducts where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            if (e.CommandName == "change")
            {
                int soldid = Convert.ToInt32(e.CommandArgument.ToString());
                Session.Add("soldid", soldid);
                Response.Redirect("ChangeStatus.aspx");
            }
        }
    }
}