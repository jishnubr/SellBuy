﻿using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Feedback : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    int ok;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["New"] != null)//Very purposeful
        {
            
        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
            ErrorChecker();
        }
        if (Page.IsPostBack != true)
        {

        }
    }
    protected void ErrorChecker()
    {
        string ProductName = "";
        string checkprod = "select count(*) from feedbackProd where Productid ='" + Convert.ToInt32(Session["Productid"].ToString()) + "' and uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "' ";
        SqlCommand com = new SqlCommand(checkprod, con);
        int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

        string sql9 = " select ProductName from Product_Details where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'";
        SqlCommand com9 = new SqlCommand(sql9, con);
        ProductName = (string)com9.ExecuteScalar();

        if (temp == 1)
        {
            Label2.Text = "Your Feedback and rating on product '" + ProductName + "' is already Exists.";
            Label3.Visible = false;
            Label4.Visible = false;
            Label1.Visible = false;
            Label5.Visible = false;
            Label6.Visible = false;
            Textfeed.Visible = false;
            TextRatng.Visible = false;
            Submit.Visible = false;
        }
        else
        {
            Label2.Text = ("You are now Feedbacking For a Product Named as '" + ProductName + "'");
             ok = 1;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        try
        {
            con.Open();
            ok = 0;
            ErrorChecker();
            if (ok == 1)
            {
                SqlCommand cmd = new SqlCommand("insert into feedbackProd(Productid,uid,feedback,Rating,Date)values('" + Convert.ToInt32(Session["Productid"].ToString()) + "','" + Convert.ToInt32(Session["uid"].ToString()) + "',@feedback,@Rating,getdate())", con);

                cmd.Parameters.AddWithValue("@feedback", Textfeed.Text);
                cmd.Parameters.AddWithValue("@Rating", TextRatng.Text);
                float f;
                bool num = float.TryParse(TextRatng.Text, out f);
                if (f <= 5 & num)
                {
                    int i = cmd.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        Label1.Visible = true;
                        Label1.Text = "Your feedback and Rating is send Successsfully";
                    }
                    else
                    {
                        Label1.Visible = false;
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Rating Should be between 0.0 to 5.0";
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}

