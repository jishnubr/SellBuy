﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
public partial class ViewCart : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    decimal totcost = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getproductdetails();
        }
    }
    private void Getproductdetails()
    {
        da = new SqlDataAdapter("select cartid,ProductImage,cost,qty,totcost,Date from cart where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "cart_Details");
        if (ds.Tables.Count > 0 && ds.Tables["cart_Details"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["cart_Details"].DefaultView;
            GridView1.DataBind();
            Label1.Visible = false;

            string ProductName = "";
            int Productid;
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label cartid = (Label)gr.Cells[1].FindControl("cartid");

                if (cartid.Text != "")
                {
                    string sql2 = " select Productid from Cart where cartid=" + Convert.ToInt32(cartid.Text) + "";
                    SqlCommand com6 = new SqlCommand(sql2, con);
                    Productid = (int)com6.ExecuteScalar();

                    string sql1 = " select ProductName from Product_Details where Productid=" + Productid + "";
                    SqlCommand com5 = new SqlCommand(sql1, con);
                    ProductName = (string)com5.ExecuteScalar();
                    if (ProductName != "")
                    {
                        gr.Cells[2].Text = ProductName;

                    }
                    else
                    {
                        gr.Cells[3].Text = "N/A";
                    }
                }
            }

            GetTotal();
        }
        else
        {
            Button1.Visible = false;

            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Your Cart is Empty";
            Label2.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
        }
    }
    private void GetTotal()
    {
        ArrayList arr = new ArrayList();
        da = new SqlDataAdapter("select totcost from Cart where uid='" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "tbl_cart1");
        if (ds.Tables.Count > 0 && ds.Tables["tbl_cart1"].Rows.Count > 0)
        {
            for (int i = 0; i < ds.Tables["tbl_cart1"].Rows.Count; i++)
            {
                arr.Add(ds.Tables["tbl_cart1"].Rows[i][0].ToString());
            }
            if (arr.Count > 0)
            {
                for (int j = 0; j < arr.Count; j++)
                {
                    totcost = totcost + Convert.ToDecimal(arr[j]);
                }
            }
        }
        Label4.Visible = true;
        Label3.Visible = true;
        Button1.Visible = true;
        Label3.Text = totcost.ToString();
    }
    protected void qty_TextChanged(object sender, EventArgs e)
    {
        int error = 0; 
        int error2 = 0;
        string ProductName = "";
        
        foreach (GridViewRow gr in GridView1.Rows)
        {
            TextBox qty = (TextBox)gr.Cells[4].FindControl("qty");
            int quantity;

            TextBox1.Text = qty.Text;
            bool num = int.TryParse(qty.Text, out quantity);
             if (num)
             {
                 quantity = Convert.ToInt32(qty.Text);

                 if (quantity <= 0)
                 {
                     gr.Cells[6].Text = "Enter Quantity Greater than zero";
                     Label4.Visible = false;
                     Label3.Visible = false;
                     Button1.Visible = false;
                     error = 1;
                 }
                 else
                 {
                     Label cartid = (Label)gr.Cells[0].FindControl("cartid");

                     Label cost = (Label)gr.Cells[4].FindControl("cost");
                     decimal totcost1 = Convert.ToDecimal(cost.Text);

                     if (cartid.Text != "")
                     {
                         string sql1 = " select Productid from cart where cartid=" + Convert.ToInt32(cartid.Text) + "";
                         SqlCommand com5 = new SqlCommand(sql1, con);
                         int Productid = (int)com5.ExecuteScalar();

                         string quty = " select totalqty from Product_Details where Productid=" + Productid + "";
                         SqlCommand com4 = new SqlCommand(quty, con);
                         int totalqty = (int)com4.ExecuteScalar();

                         string quty1 = " select Remainitems  from Product_Details where Productid=" + Productid + "";
                         SqlCommand com6 = new SqlCommand(quty1, con);
                         int Remainitems = (int)com6.ExecuteScalar();

                         string quty2 = " select qty from Cart where cartid=" + Convert.ToInt32(cartid.Text) + "";
                         SqlCommand com7 = new SqlCommand(quty2, con);
                         int cartqty = (int)com7.ExecuteScalar();


                         string sql7 = " select ProductName from Product_Details where Productid=" + Productid + "";
                         SqlCommand com9 = new SqlCommand(sql7, con);
                         ProductName = (string)com9.ExecuteScalar();
                         if (ProductName != "")
                         {
                             gr.Cells[2].Text = ProductName;

                         }
                         else
                         {
                             gr.Cells[2].Text = "N/A";
                         }

                         int avail = Remainitems + cartqty;
                         if (quantity > avail)
                         {
                             gr.Cells[6].Text = "So much no.of pieces is not available";
                             Label4.Visible = false;
                             Label3.Visible = false;
                             Button1.Visible = false;
                             error2 = 1;
                         }

                         else if (quantity <= avail)
                         {
                             totcost1 = totcost1 * quantity;
                             gr.Cells[6].Text = totcost1.ToString();

                             da = new SqlDataAdapter("update Cart set qty=" + quantity + ",totcost=" + totcost1 + " where cartid=" + Convert.ToInt32(cartid.Text) + " and uid=" + Convert.ToInt32(Session["uid"].ToString()) + " ", con);
                             int n = da.SelectCommand.ExecuteNonQuery();

                             if (n == 1)
                             {
                                 int Remain = Remainitems;
                                 if (quantity > cartqty)
                                 {
                                     Remain = Remainitems - (quantity - cartqty);
                                 }
                                 if (quantity < cartqty)
                                 {
                                     Remain = Remainitems + (cartqty - quantity);
                                 }
                                 da = new SqlDataAdapter("update Product_Details  set Remainitems =" + Remain + " where Productid='" + Productid + "' ", con);
                                 da.SelectCommand.ExecuteNonQuery();
                             }
                         }
                     }
                 }
             }
             else
             {
                 gr.Cells[6].Text = "Invalid Quantity";
                 Label4.Visible = false;
                 Label3.Visible = false;
                 Button1.Visible = false;
                 error = 1;
             }
        }
        if (error != 1 && error2 != 1)
        {
            GetTotal();
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        da = new SqlDataAdapter("select cartid,ProductImage,cost,qty,totcost,Date from cart where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "cart_Details");
        if (ds.Tables.Count > 0 && ds.Tables["cart_Details"].Rows.Count > 0)
        {
            Label cartid = new Label();
            cartid = (Label)GridView1.Rows[e.RowIndex].Cells[1].FindControl("cartid");

            if (cartid.Text != "")
            {
                string sql1 = " select Productid from cart where cartid=" + Convert.ToInt32(cartid.Text) + "";
                SqlCommand com5 = new SqlCommand(sql1, con);
                int Productid = (int)com5.ExecuteScalar();

                string quty = " select Remainitems from Product_Details where Productid=" + Productid + "";
                SqlCommand com4 = new SqlCommand(quty, con);
                int quaty = (int)com4.ExecuteScalar();
                quaty = quaty + 1;

                da = new SqlDataAdapter("update Product_Details  set Remainitems =" + quaty + " where Productid='" + Productid + "' ", con);
                da.SelectCommand.ExecuteNonQuery();

                da = new SqlDataAdapter("delete from Cart where cartid=" + Convert.ToInt32(cartid.Text) + "", con);
                int n = da.SelectCommand.ExecuteNonQuery();
                GridView1.DataBind();
                if (n == 1)
                {
                    Getproductdetails();
                }
            }
        }
        else
        {
            Button1.Visible = false;
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Your Cart is Empty";
            Label2.Visible = false;
            Label3.Visible = false;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getproductdetails();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ArrayList arr = new ArrayList();
        if (Session.Count > 0)
        {
            da = new SqlDataAdapter("select cartid from Cart where uid='" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tbl_cart");
            if (ds.Tables.Count > 0 && ds.Tables["tbl_cart"].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables["tbl_cart"].Rows.Count; i++)
                {
                    arr.Add(ds.Tables["tbl_cart"].Rows[i][0].ToString());
                }
                if (arr.Count > 0)
                {
                    for (int j = 0; j < arr.Count; j++)
                    {
                        da = new SqlDataAdapter("select Productid,ProductImage,qty from Cart where cartid=" + arr[j] + " ", con);
                        ds = new DataSet();
                        da.Fill(ds, "tbl_cart");
                        if (ds.Tables.Count > 0 && ds.Tables["tbl_cart"].Rows.Count > 0)
                        {
                            da = new SqlDataAdapter("insert into soldProducts(Productid,uid,ProductImage,soldqty,Date,Status)values(" + ds.Tables["tbl_cart"].Rows[0][0].ToString() + ",'" + Convert.ToInt32(Session["uid"].ToString()) + "','" + ds.Tables["tbl_cart"].Rows[0][1].ToString() + "','" + ds.Tables["tbl_cart"].Rows[0][2].ToString() + "',getdate(),'Not Initiated')", con);
                            int n = da.SelectCommand.ExecuteNonQuery();
                            if (n == 1)
                            {
                                da = new SqlDataAdapter("delete from Cart where cartid=" + arr[j] + " ", con);
                                int n1 = da.SelectCommand.ExecuteNonQuery();
                            }
                        }
                    }
                } 
                Response.Redirect("Boughtproduct.aspx");
            }
        }
    }
}