﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Seller_and_Buyer_soldproducts_aspx : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getsoldproductdetailsfromproductdetails();
        }
    }
    private void Getsoldproductdetailsfromproductdetails()
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems,Type,Date from Product_Details where Remainitems='0' and uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");

        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {

            GridView1.DataSource = ds.Tables["Product_Details"].DefaultView;

            Label1.Visible = false;
            GridView1.DataBind();
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "Your Sold Products List is Empty";
            Label2.Visible = false;
        }
    }
   
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems ,Type,Date from Product_Details where Remainitems='0' and uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "' ", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            Label Productid = new Label();
            Productid = (Label)GridView1.Rows[e.RowIndex].Cells[0].FindControl("Productid");

            if (Productid.Text != "")
            {

                string checkuser = " select count(*) from soldProducts where  Productid = '" + Productid.Text + "' and Status != 'Finished'";
                SqlCommand com = new SqlCommand(checkuser, con);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString().Replace(" ", ""));

                if (temp == 1)
                {
                    Label1.Visible = true;
                    Label1.Text = "This Product can not be deleted .Because Product Delivery of all pieces is not finished";

                }
                else
                {
                    da = new SqlDataAdapter("delete from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "", con);
                    int n = da.SelectCommand.ExecuteNonQuery();
                    GridView1.DataBind();
                    if (n == 1)
                    {
                        da = new SqlDataAdapter("delete from soldProducts where Productid=" + Convert.ToInt32(Productid.Text) + "", con);
                        int o = da.SelectCommand.ExecuteNonQuery();
                        if (o == 1)
                        {
                            da = new SqlDataAdapter("delete from feedbackProd where Productid=" + Convert.ToInt32(Productid.Text) + "", con);
                            int p = da.SelectCommand.ExecuteNonQuery();
                        }
                        Getsoldproductdetailsfromproductdetails();
                    }

                }
            }
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "Your Sold Products List is Empty";
            Label2.Visible = false;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getsoldproductdetailsfromproductdetails();
    }
}