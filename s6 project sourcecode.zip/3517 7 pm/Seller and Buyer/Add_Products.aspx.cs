﻿using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
public partial class Add_Products : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {
            
        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (Page.IsPostBack != true)
        {
            GetItemType();
        }
    }
    private void GetItemType()
    {
        da = new SqlDataAdapter("select Category from Category", con);
        ds = new DataSet();
        da.Fill(ds, "Category");
        if (ds.Tables.Count > 0 && ds.Tables["Category"].Rows.Count > 0)
        {
            DropDowncategory.DataTextField = "Category";
            DropDowncategory.DataValueField = "Category";
            DropDowncategory.DataBind();
            DropDowncategory.Items.Insert(0, "--select--");
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void DropDowncategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Visible = true;
        DropDownsubcategory.Visible = true;
        DropDownsubcategory.DataBind();
        DropDownsubcategory.Items.Insert(0, "--select--");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        try
        {
            con.Open();
            string brID = " select BrandID from Subcategory where BrandName='" + DropDownsubcategory.Text + "'";
            SqlCommand com1 = new SqlCommand(brID, con);

            int BrandID = (int)com1.ExecuteScalar();
            if (FileUploadimage.PostedFile.FileName != "")
            {
                    string fileExtension = Path.GetExtension(FileUploadimage.PostedFile.FileName);
                    if (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".bmp" || fileExtension.ToLower() == ".gif" || fileExtension.ToLower() == ".png")
                    {
                        string str = FileUploadimage.FileName;
                        FileUploadimage.SaveAs(Server.MapPath("~/Images/" + str.ToString()));
                        string path = "~/Images/" + str.ToString();
                        string RadioButtontype = RadioButton1.Text;
                        if (RadioButton1.Checked)
                        {
                            RadioButtontype = RadioButton1.Text;
                        }
                        else if (RadioButton2.Checked)
                        {
                            RadioButtontype = RadioButton2.Text;
                        }
                        if (Textprice.Text == "0" || Textquantity.Text == "0")
                        {
                            Label1.Visible = true;
                            Label1.Text = "All Numbers Must be Greater than zero";
                        }
                        else
                        {
                            SqlCommand cmd = new SqlCommand("insert into Product_Details(ProductName,uid,BrandID,description,ProductImage,cost,totalqty ,Remainitems ,Type,Date)values(@Textprodname,'" + Convert.ToInt32(Session["uid"].ToString()) + "','" + BrandID + "',@Textproddes,'" + path + "',@Textprice,@Textquantity,@Textquantity,'" + RadioButtontype + "',getdate())", con);
          
                            cmd.Parameters.AddWithValue("@Textprodname", Textprodname.Text);
                            cmd.Parameters.AddWithValue("@Textproddes", Textproddes.Text);
                            cmd.Parameters.AddWithValue("@Textprice", Textprice.Text);
                            cmd.Parameters.AddWithValue("@Textquantity", Textquantity.Text);

                            string checkprod = "select count(*) from Product_Details where ProductName ='" + Textprodname.Text + "' and uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "' and BrandID = '" + BrandID + "' and description = '" + Textproddes.Text + "' and cost = '" + Textprice.Text + "' and totalqty = '" + Textquantity.Text + "'  and Type = '" + RadioButtontype + "' ";
                            SqlCommand com = new SqlCommand(checkprod, con);
                            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

                            if (temp == 1)
                            {
                                Label1.Text = "Product already Exists.";
                                Label1.Visible = true;
                            }
                            else
                            {
                                cmd.ExecuteNonQuery();
                                con.Close();
                                Label1.Visible = true;
                                Label1.Text = "Your Product Details uploaded Successsfully";
                            }
                        }
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.Text = "Only images (.jpg,.png,.bmp,.gif) can be uploaded";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "please upload an image";
                }
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}
   
