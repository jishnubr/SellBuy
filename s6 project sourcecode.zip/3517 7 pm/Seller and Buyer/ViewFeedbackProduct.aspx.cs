﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;

public partial class Seller_and_Buyer_ViewFeedbackProduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da, db;
    DataSet ds, dt;
    decimal totRatng = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getfeedback();
        }
    }
    private void Getfeedback()
    {
        ArrayList arr = new ArrayList();
        da = new SqlDataAdapter("select Feedbkprodid,Productid,uid,feedback,Date,Rating from feedbackProd where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "' ", con);
        ds = new DataSet();
        da.Fill(ds, "feedbackProd");

        string ProductName = "";
        if (ds.Tables.Count > 0 && ds.Tables["feedbackProd"].Rows.Count > 0)
        {
            string sql9 = " select ProductName from Product_Details where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'";
            SqlCommand com9 = new SqlCommand(sql9, con);
            ProductName = (string)com9.ExecuteScalar();

            Label1.Visible = true;
            Label1.Text = ("You are now Viewing Feedbacks For a Product Named as '" + ProductName + "'");

            GridView1.DataSource = ds.Tables["feedbackProd"].DefaultView;
            GridView1.DataBind();
            string username = "";
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label uid = (Label)gr.Cells[0].FindControl("uid");
                if (uid.Text != "")
                {
                    string sql1 = " select username from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                    SqlCommand com5 = new SqlCommand(sql1, con);
                    username = (string)com5.ExecuteScalar();
                    gr.Cells[3].Text = username;
                }
                 /*Rating */
                float Ratng = 0;
                int Count,le = 0;
                string r = "";
                    db = new SqlDataAdapter(" select Rating from feedbackProd where Productid='" + Convert.ToInt32(Session["Productid"].ToString()) + "'", con);
                    dt = new DataSet();
                    db.Fill(dt, "Rating");
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count == 1)
                    {
                        r = dt.Tables["Rating"].Rows[0][0].ToString();
                    }
                    if (dt.Tables.Count > 0 && dt.Tables["Rating"].Rows.Count > 1)
                    {
                        
                        ArrayList ar = new ArrayList();
                        for (int i = 0; i < dt.Tables["Rating"].Rows.Count; i++)
                        {
                            ar.Add(dt.Tables["Rating"].Rows[i][0].ToString());
                        }
                        if (ar.Count > 0)
                        {
                            for (int j = 0; j < ar.Count; j++)
                            {
                                totRatng = totRatng + Convert.ToDecimal(ar[j]);
                            }
                            Count = ar.Count;

                            Ratng = (float)(totRatng / (Count * Count) );
                        }
                        le = Convert.ToInt32(Ratng.ToString().Length.ToString());
                        r = Ratng.ToString();
                        if(le > 3)
                        {
                            r = Ratng.ToString().Remove(3);
                        }
                    }
                    Label3.Visible = true;
                    Label3.Text = ("Overall Product Rating is " + r + " ");

            }
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "No Feedback is Received";
            Label2.Visible = false;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getfeedback();
    }

}