﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Seller_and_Buyer_Boughtproduct_aspx : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getproductdetails();
        }
    }
    private void Getproductdetails()
    {
        da = new SqlDataAdapter("select soldid,Productid,ProductImage,soldqty,Date,Status from soldProducts where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["soldProduct_Details"].DefaultView;
            GridView1.DataBind();
            Label1.Visible = false;

            string ProductName;
            string username;
            int uid;
            string cost;
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label Productid = (Label)gr.Cells[0].FindControl("Productid");

                if (Productid.Text != "")
                {
                    string sql1 = " select ProductName from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com5 = new SqlCommand(sql1, con);
                    ProductName = (string)com5.ExecuteScalar();
                    if (ProductName != "")
                    {
                        gr.Cells[3].Text = ProductName;
                    }

                    string sql4 = " select cost from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com4 = new SqlCommand(sql4, con);
                    cost = Convert.ToString(com4.ExecuteScalar());
                    if (cost != "")
                    {
                        gr.Cells[7].Text = cost;
                    }

                    string sql3 = " select uid from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com3 = new SqlCommand(sql3, con);
                    uid = (int)com3.ExecuteScalar();

                    string sql2 = " select username from Users where uid=" + uid + "";
                    SqlCommand com2 = new SqlCommand(sql2, con);
                    username = (string)com2.ExecuteScalar();
                    if (username != "")
                    {
                        gr.Cells[4].Text = username;
                    }
                    else
                    {
                    }
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Text = "Your Purchased items list is Empty";
            Label2.Visible = false;
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        da = new SqlDataAdapter("select soldid,Productid,ProductImage,soldqty,Date from soldProducts where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "soldProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["soldProduct_Details"].Rows.Count > 0)
        {
            Label soldid = new Label();
            soldid = (Label)GridView1.Rows[e.RowIndex].Cells[0].FindControl("soldid");

            if (soldid.Text != "")
            {

                string checkuser = " select count(*) from soldProducts where  soldid = '" + soldid.Text + "' and Status != 'Finished'";
                SqlCommand com = new SqlCommand(checkuser, con);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString().Replace(" ", ""));

                if (temp == 1)
                {
                    Getproductdetails();
                    Label1.Visible = true;
                    Label1.Text = "This Product can not be deleted .Because Product Delivery of all pieces is not finished";
                    
                }
                else
                {
                    da = new SqlDataAdapter("delete from soldProducts where soldid=" + Convert.ToInt32(soldid.Text) + "", con);
                    int n = da.SelectCommand.ExecuteNonQuery();
                    GridView1.DataBind();
                    if (n == 1)
                    {
                        Getproductdetails();
                    }
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Your List is Empty";
            Label2.Visible = false;
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        da = new SqlDataAdapter("select soldid,Productid,ProductImage,soldqty,Date from soldProducts where uid = '" + Convert.ToInt32(Session["uid"].ToString()) + "'", con);
        ds = new DataSet();
        da.Fill(ds, "BoughtProduct_Details");
        if (ds.Tables.Count > 0 && ds.Tables["BoughtProduct_Details"].Rows.Count > 0)
        {
            if (e.CommandName == "SendFeedback")
            {
                int Productid = Convert.ToInt32(e.CommandArgument.ToString());
                Session.Add("Productid", Productid);
                Response.Redirect("FeedbackProduct.aspx");
            }
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getproductdetails();
    }
}