﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class Add_Category : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)
        {
            con.Open();
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            if (TextCategory.Text == "")
            {
                Label1.Visible = true;
            }
            else
            {
                string checkuser = " select count(*) from Category where Category=@Textsubcategory";
                SqlCommand com = new SqlCommand(checkuser, con);
                com.Parameters.AddWithValue("@Textsubcategory", TextCategory.Text);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

                if (temp == 1)
                {
                    Label1.Visible = true;
                    Label1.Text = "Category already Exists";
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into Category values( '" + TextCategory.Text + "')", con);
                    cmd.Parameters.AddWithValue("@Textsubcategory", TextCategory.Text);
                    cmd.ExecuteNonQuery();

                    con.Close();
                    Label1.Visible = true;
                    Label1.Text = "Your Category Addded Successsfully";
                    TextCategory.Text = "";
                }
            }
        }
        catch(Exception ex)
        {
            Response.Write("Error:"+ex.ToString());
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
}