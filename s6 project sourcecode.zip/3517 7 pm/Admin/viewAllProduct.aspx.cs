﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
public partial class Seller_and_Buyer_viewMyProduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getunsoldproductdetailsfromproductdetails();
        }
    }
    private void Getunsoldproductdetailsfromproductdetails()
    {
        da = new SqlDataAdapter("select Productid,ProductName,description,ProductImage,cost,totalqty,Remainitems,Type,Date from Product_Details", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");

        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {

            GridView1.DataSource = ds.Tables["Product_Details"].DefaultView;

            Label1.Visible = false;
            GridView1.DataBind();
            string username;
            int uid;
            foreach (GridViewRow gr in GridView1.Rows)
            {
                Label Productid = (Label)gr.Cells[1].FindControl("Productid");
                if (Productid.Text != "")
                {
                    string sql1 = " select uid from Product_Details where Productid=" + Convert.ToInt32(Productid.Text) + "";
                    SqlCommand com1 = new SqlCommand(sql1, con);
                    uid = (int)com1.ExecuteScalar();


                    string sql2 = " select username from Users where uid=" + uid + "";
                    SqlCommand com2 = new SqlCommand(sql2, con);
                    username = (string)com2.ExecuteScalar();
                    if (username != "")
                    {
                        gr.Cells[2].Text = username;
                    }
                }
            }

        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "Your Products List is Empty";
            Label2.Visible = false;
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getunsoldproductdetailsfromproductdetails();
    }

}