﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
public partial class Admin_viewFeedbacks : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds,dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            Getfeedback();
        }
    }
    private void Getfeedback()
    {
        ArrayList arr = new ArrayList();
        da = new SqlDataAdapter("select Feedbackid,uid,feedback,Date from feedbackSite ", con);
        ds = new DataSet();
        da.Fill(ds, "feedbackSite");

        if (ds.Tables.Count > 0 && ds.Tables["feedbackSite"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["feedbackSite"].DefaultView;
            GridView1.DataBind();
            Label1.Visible = false;
            string username = "";
             foreach (GridViewRow gr in GridView1.Rows)
             {
                 Label uid = (Label)gr.Cells[0].FindControl("uid");

                 if (uid.Text != "")
                 {
                     string sql1 = " select username from Users where uid=" + Convert.ToInt32(uid.Text) + "";
                     SqlCommand com5 = new SqlCommand(sql1, con);
                     username = (string)com5.ExecuteScalar();
                     gr.Cells[2].Text = username;
                 }
             }
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "No Feedback is Received";
            Label2.Visible = false;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Getfeedback();
    }

}