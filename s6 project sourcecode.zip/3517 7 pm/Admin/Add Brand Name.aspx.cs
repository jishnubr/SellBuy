﻿using System;
using System.Data.SqlClient;
using System.Configuration;

public partial class Add_SubCategory : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)
        {
            con.Open();
        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            if (Textsubcategory.Text == "")
            {
                Label1.Visible = true;
            }
            else
            {
                string checkuser = " select count(*) from Subcategory where BrandName=@Textsubcategory";

                SqlCommand com = new SqlCommand(checkuser, con); 
                com.Parameters.AddWithValue("@Textsubcategory", Textsubcategory.Text);
                com.ExecuteNonQuery();
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

                if (temp == 1)
                {
                    Label1.Visible = true;
                    Label1.Text = "Brand Name already Exists";
                }
                else
                {
                    string CatID = " select CatID from Category where Category='" + DropDownList1.Text + "'";
                    SqlCommand com1 = new SqlCommand(CatID, con);
                    int ID = (int)com1.ExecuteScalar();
                    SqlCommand cmd = new SqlCommand("insert into Subcategory values( '" + ID + "',@Textsubcategory,'" + DropDownList1.Text + "')", con);
                    
                    cmd.Parameters.AddWithValue("@Textsubcategory", Textsubcategory.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Label1.Visible = true;
                    Label1.Text = "Your Brand Name Added Successsfully";
                    Textsubcategory.Text = "";
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
       Label2.Visible = true;
       Textsubcategory.Visible = true;
    }
}