﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
public partial class Seller_and_Buyer_CustomerView : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {

        }
        else
        {
            Response.Redirect("AdminLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (!Page.IsPostBack)
        {
            GetCustomers();
        }
    }
    private void GetCustomers()
    {
        ArrayList arr = new ArrayList();
        da = new SqlDataAdapter("select * from Users", con);
        ds = new DataSet();
        da.Fill(ds, "tbl_Users");
        if (ds.Tables.Count > 0 && ds.Tables["tbl_Users"].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables["tbl_Users"].DefaultView;
            GridView1.DataBind();
            Label1.Visible = false;
        }
        else
        {
            Label1.ForeColor = System.Drawing.Color.Red;
            Label1.Visible = true;
            Label1.Text = "No Users";
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GetCustomers();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Block")
        {
                da = new SqlDataAdapter("select status from Users where uid=" + Convert.ToInt32(e.CommandArgument.ToString()) + " ", con);
                ds = new DataSet();
                da.Fill(ds, "Users");
                if (ds.Tables.Count > 0 && ds.Tables["Users"].Rows.Count > 0)
                {
                    if (ds.Tables["Users"].Rows[0][0].ToString() == "Active")
                    {
                        da = new SqlDataAdapter("update Users set status='Blocked' where uid=" + Convert.ToInt32(e.CommandArgument.ToString()) + " ", con);
                        int n = da.SelectCommand.ExecuteNonQuery();
                        if (n == 1)
                        {
                            GetCustomers();
                        }
                    }
                    else if (ds.Tables["Users"].Rows[0][0].ToString() == "Blocked")
                    {
                        da = new SqlDataAdapter("update Users set status='Active' where uid=" + Convert.ToInt32(e.CommandArgument.ToString()) + " ", con);
                        int n = da.SelectCommand.ExecuteNonQuery();
                        if (n == 1)
                        {
                            GetCustomers();
                        }
                    }
                }
        }
    }
}