﻿using System;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class UserLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack != true)
        {
            Session["New"] = null;
        }
    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        string checkuser = " select count(*) from Users where username=@username and status='Active'";
        SqlCommand com = new SqlCommand(checkuser, con);
        com.Parameters.AddWithValue("@username", TextBox1.Text);
        int temp = Convert.ToInt32(com.ExecuteScalar().ToString().Replace(" ", ""));
        con.Close();
        if (temp == 1)
        {
            con.Open();
            string checkPasswordQuery = " select pass from Users where username=@username";
            SqlCommand passComm = new SqlCommand(checkPasswordQuery, con);
            passComm.Parameters.AddWithValue("@username", TextBox1.Text);
            string password = passComm.ExecuteScalar().ToString();
            if (password == TextBox2.Text)
            {
                Session["New"] = TextBox1.Text;
                string user = " select uid from Users where username= @username";
                SqlCommand com1 = new SqlCommand(user, con);

                com1.Parameters.AddWithValue("@username", TextBox1.Text);

                string uid = com1.ExecuteScalar().ToString();
                Session.Add("uid", uid);
                Response.Redirect("UserPage.aspx");
            }
            else if (TextBox2.Text != "")
            {
                Label1.Visible = true;
                Label1.Text = "Password is not correct";
            }
        }
        else if (TextBox1.Text == "")
        {
            Label1.Visible = false;
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "Username is not correct or Blocked By Admin";
        }
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}