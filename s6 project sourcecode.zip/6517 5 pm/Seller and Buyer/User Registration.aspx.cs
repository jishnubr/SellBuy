﻿using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class User_Registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (Page.IsPostBack != true)
        {
            Session["New"] = null;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            if (Textfname.Text == "" || Textlname.Text == "" || Textaddress.Text == "" || Textcity.Text == "" || Textzip.Text == "" || Textstate.Text == "" || Textemail.Text == "" || Textpass.Text == "" || Textphone.Text == "" || Textconfpass.Text == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please fill All Details";
            }
            else
            {
                string checkuser = " select count(*) from Users where username='" + TextUser.Text + "'";
                SqlCommand com = new SqlCommand(checkuser, con);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());

                if (temp == 1)
                {
                    Label1.Visible = true;
                    Label1.Text = "User already Exists.Please Try Another Name";
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into Users values( @Textfname,@Textlname,@Textaddress,@Textcity,@Textzip,@Textstate,@Textemail,@TextUser,'Active',@Textpass,@Textphone)", con);

                    cmd.Parameters.AddWithValue("@Textfname", Textfname.Text);
                    cmd.Parameters.AddWithValue("@Textlname", Textlname.Text);
                    cmd.Parameters.AddWithValue("@Textaddress", Textaddress.Text);
                    cmd.Parameters.AddWithValue("@Textcity", Textcity.Text);
                    cmd.Parameters.AddWithValue("@Textzip", Textzip.Text);
                    cmd.Parameters.AddWithValue("@Textstate", Textstate.Text);
                    cmd.Parameters.AddWithValue("@Textemail", Textemail.Text);
                    cmd.Parameters.AddWithValue("@TextUser", TextUser.Text);
                    cmd.Parameters.AddWithValue("@Textpass", Textpass.Text);
                    cmd.Parameters.AddWithValue("@Textphone", Textphone.Text);

                    cmd.ExecuteNonQuery();
                    con.Close();
                    Label1.Text = "Your Data Stored Successsfully";
                    Label1.Visible = true;
                    Textfname.Text = "";
                    Textlname.Text = "";
                    Textaddress.Text = "";
                    Textcity.Text = "";
                    Textzip.Text = "";
                    Response.Redirect("UserLogin.aspx");
                }
            }
        }
        catch(Exception ex)
        {
            Response.Write("Error:"+ex.ToString());
        }
    }
}