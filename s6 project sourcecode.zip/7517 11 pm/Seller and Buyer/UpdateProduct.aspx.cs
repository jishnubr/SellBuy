﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.IO;
public partial class Seller_and_Buyer_UpdateProduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {
            con.Open();
            GetProductDetails(Convert.ToInt32(Session["Productid"].ToString()));
        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        }
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (Page.IsPostBack != true)
        {
            GetItemType();
        }
    }
    private void GetProductDetails(int Productid)
    {
        da = new SqlDataAdapter("select ProductName,description,cost,totalqty  from Product_Details where Productid=" + Productid + " ", con);
        ds = new DataSet();
        da.Fill(ds, "Product_Details");
        if (ds.Tables.Count > 0 && ds.Tables["Product_Details"].Rows.Count > 0)
        {
            /*Textprodname.Text = ds.Tables["Product_Details"].Rows[0][0].ToString();
            Textproddes.Text = ds.Tables["Product_Details"].Rows[0][1].ToString();
            Textprice.Text = ds.Tables["Product_Details"].Rows[0][2].ToString();
            Textquantity.Text = ds.Tables["Product_Details"].Rows[0][3].ToString();*/
        }
    }
    private void GetItemType()
    {
        da = new SqlDataAdapter("select Category from Category", con);
        ds = new DataSet();
        da.Fill(ds, "Category");
        if (ds.Tables.Count > 0 && ds.Tables["Category"].Rows.Count > 0)
        {
            DropDowncategory.DataTextField = "Category";
            DropDowncategory.DataValueField = "Category";
            DropDowncategory.DataBind();
            DropDowncategory.Items.Insert(0, "--select--");
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void DropDowncategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Visible = true;
        DropDownsubcategory.Visible = true;
        DropDownsubcategory.DataBind();
        DropDownsubcategory.Items.Insert(0, "--select--");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        try
        {
            if (DropDownsubcategory.Text != "--select--" && DropDowncategory.Text != "--select--")
            {
                con.Open();
                string brID = " select BrandID from Subcategory where BrandName='" + DropDownsubcategory.Text + "'";
                SqlCommand com1 = new SqlCommand(brID, con);
                int BrandID = (int)com1.ExecuteScalar();

                if (FileUploadimage.PostedFile.FileName != "")
                {
                    string fileExtension = Path.GetExtension(FileUploadimage.PostedFile.FileName);
                    if (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".bmp" || fileExtension.ToLower() == ".gif" || fileExtension.ToLower() == ".png")
                    {
                        string str = FileUploadimage.FileName;
                        FileUploadimage.SaveAs(Server.MapPath("~/Images/" + str.ToString()));
                        string path = "~/Images/" + str.ToString();
                        string RadioButtontype = RadioButton1.Text;
                        if (RadioButton1.Checked)
                        {
                            RadioButtontype = RadioButton1.Text;
                        }
                        else if (RadioButton2.Checked)
                        {
                            RadioButtontype = RadioButton2.Text;
                        }
                        if (Textprice.Text == "0" || Textquantity.Text == "0")
                        {
                            Label1.Visible = true;
                            Label1.Text = "All Numbers Must be Greater than zero";
                        }
                        else
                        {
                            SqlCommand cmd = new SqlCommand("update Product_Details  set  ProductName = @Textprodname  where  Productid= '" + Convert.ToInt32(Session["Productid"].ToString()) + "' ", con);

                            cmd.Parameters.AddWithValue("@Textprodname", Textprodname.Text);
                            cmd.Parameters.AddWithValue("@Textproddes", Textproddes.Text);
                            cmd.Parameters.AddWithValue("@Textprice", Textprice.Text);
                            cmd.Parameters.AddWithValue("@Textquantity", Textquantity.Text);

                            cmd.ExecuteNonQuery();
                            con.Close();
                            Label1.Visible = true;
                            Label1.Text = "Your Product Details uploaded Successsfully";
                        }
                    }
                    else
                    {
                        Label1.Visible = true;
                        Label1.Text = "Only images (.jpg,.png,.bmp,.gif) can be uploaded";
                    }
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "please upload an image";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Select a Brand Name";
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}