﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Seller_and_Buyer_UpdateProfile : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["New"] != null)//Very purposeful
        {
            con.Open();
            GetUserProfile(Convert.ToInt32(Session["uid"].ToString()));
        }
        else
        {
            Response.Redirect("UserLogin.aspx");
        } 
    }
    private void GetUserProfile(int uid)
    {
     /*   da = new SqlDataAdapter("select fname,lname,address,city,zip,state,email,phone from Users where uid=" + uid + " ", con);
        ds = new DataSet();
        da.Fill(ds, "tbl_Users");
        if (ds.Tables.Count > 0 && ds.Tables["tbl_Users"].Rows.Count > 0)
        {
            Textfname.Text = ds.Tables["tbl_Users"].Rows[0][0].ToString();
            Textlname.Text = ds.Tables["tbl_Users"].Rows[0][1].ToString();
            Textaddress.Text = ds.Tables["tbl_Users"].Rows[0][2].ToString();
            Textcity.Text = ds.Tables["tbl_Users"].Rows[0][3].ToString();
            Textzip.Text = ds.Tables["tbl_Users"].Rows[0][4].ToString();
            Textstate.Text = ds.Tables["tbl_Users"].Rows[0][5].ToString();
            Textemail.Text = ds.Tables["tbl_Users"].Rows[0][6].ToString();
            Textphone.Text = ds.Tables["tbl_Users"].Rows[0][7].ToString();
        }*/
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            if (Textfname.Text == "" || Textlname.Text == "" || Textaddress.Text == "" || Textcity.Text == "" || Textzip.Text == "" || Textstate.Text == "" || Textemail.Text == "" || Textpass.Text == "" || Textphone.Text == "" || Textconfpass.Text == "")
            {
                Label1.Visible = true;
                Label1.Text = "Please fill All Details";
            }
            else
            {
                SqlCommand cmd = new SqlCommand("update Users set fname=@Textfname,lname=@Textlname,address=@Textaddress,city=@Textcity,zip=@Textzip,state=@Textstate,email=@Textemail,pass=@Textpass,phone=@Textphone where uid=" + Convert.ToInt32(Session["uid"].ToString()) + " ", con);

                cmd.Parameters.AddWithValue("@Textfname", Textfname.Text);
                cmd.Parameters.AddWithValue("@Textlname", Textlname.Text);
                cmd.Parameters.AddWithValue("@Textaddress", Textaddress.Text);
                cmd.Parameters.AddWithValue("@Textcity", Textcity.Text);
                cmd.Parameters.AddWithValue("@Textzip", Textzip.Text);
                cmd.Parameters.AddWithValue("@Textstate", Textstate.Text);
                cmd.Parameters.AddWithValue("@Textemail", Textemail.Text);
                cmd.Parameters.AddWithValue("@Textpass", Textpass.Text);
                cmd.Parameters.AddWithValue("@Textphone", Textphone.Text);

                cmd.ExecuteNonQuery();
                con.Close();
                Label1.Text = "Your Data Stored Successsfully";
                Label1.Visible = true;
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}